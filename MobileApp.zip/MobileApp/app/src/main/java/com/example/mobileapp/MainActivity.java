package com.example.mobileapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.Button;
import android.content.Intent;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.material.button.MaterialButton;


public class MainActivity extends AppCompatActivity {
    public Button button;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        EditText username;
        username = findViewById(R.id.username);
        EditText password;
        password = findViewById(R.id.password);

        MaterialButton btn_login = (MaterialButton) findViewById(R.id.btn_login);

        //username = admin and password = admin

        btn_login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(username.getText().toString().equals("admin") && password.getText().toString().euqals("admin")) {
                    //correct
                    Toast.makeText(MainActivity.this, "Login Successful", Toast.LENGTH_SHORT).show();
                }else
                    //incorrect
                    Toast.makeText(MainActivity.this, "Login Failed", Toast.LENGTH_SHORT).show();
            }
        });
        button= (Button) findViewById(R.id.btn_login);

        button.setOnClickListener(view -> {
            Intent intent  = new Intent(MainActivity.this,registration.class);
            startActivity(intent);
        });
    }

    public void OpenRegistration(View view) {
        startActivity(new Intent(this,registration.class));
    }
}






